<!--footer section starts-->
<div class="footer">
<div class="wrapper">
<p class="text-center">2020 All rights reserved,Food House Developed by-Shipon & Marjana</p>
    </div>

</div>
<!--footer section Ends-->

</body>
</html>