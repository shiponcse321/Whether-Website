<?php 
include('../config/constant.php');
include('login-check.php');
?>

<html>
<head>
<title> Food ordering website -Home page</title>
<link rel="stylesheet" href="../css/admin.css">
</head>
<body>
<!--manu section starts-->
<div class="menu text-center">
    <div class="wrapper">
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="manage-admin.php">Admin</a></li>
            <li><a href="manage-category.php">Catergory</a></li>
            <li><a href="manage-food.php">Food</a></li>
            <li><a href="manage-order.php">Order</a></li>
            <li><a href="logout.php">Logout</a></li>

        </ul>
    </div>

</div>

<!--manu section Ends-->