<?php
$servername = "localhost";
$username = "root";
$password = "";
$databasebname = "online-food-order";
$conn = new mysqli($servername,$username,$password,$databasebname);
?>
