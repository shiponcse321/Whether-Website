<!--footer section starts-->
<div class="footer">
<div class="wrapper">
<p class="text-center">2021 All rights reserved,Canteen Management System Developed by-Shipon & Marjana</p>
    </div>

</div>
<!--footer section Ends-->

</body>
</html>